
import React, { useState } from 'react';

const questions = [
    "Can you code in Ruby?",
    "Can you code in JavaScript?",
    "Can you code in Swift?",
    "Can you code in Java?",
    "Can you code in C#?"
];

const App = () => {
    const [answers, setAnswers] = useState(Array(questions.length).fill(null));
    const [score, setScore] = useState(null);

    const handleAnswer = (index, answer) => {
        const newAnswers = [...answers];
        newAnswers[index] = answer;
        setAnswers(newAnswers);
    };

    const calculateScore = () => {
        const yesCount = answers.filter(answer => answer === 'yes').length;
        const calculatedScore = (100 * yesCount) / questions.length;
        setScore(calculatedScore);
    };

    const handleSubmit = () => {
        calculateScore();
        resetAnswers();
    };

    const resetAnswers = () => {
        setAnswers(Array(questions.length).fill(null));
    };

    return (
        <div className="container mt-5">
            <h1 className="text-center mb-4">Yes/No Questions</h1>
            <div className="card p-4">
                <div className="mb-3">
                    {questions.map((question, index) => (
                        <div className="form-group" key={index}>
                            <label>{question}</label>
                            <div>
                                <div className="form-check form-check-inline">
                                    <input 
                                        className="form-check-input" 
                                        type="radio" 
                                        name={`question-${index}`} 
                                        value="yes" 
                                        checked={answers[index] === 'yes'} 
                                        onChange={() => handleAnswer(index, 'yes')} 
                                    />
                                    <label className="form-check-label">Yes</label>
                                </div>
                                <div className="form-check form-check-inline">
                                    <input 
                                        className="form-check-input" 
                                        type="radio" 
                                        name={`question-${index}`} 
                                        value="no" 
                                        checked={answers[index] === 'no'} 
                                        onChange={() => handleAnswer(index, 'no')} 
                                    />
                                    <label className="form-check-label">No</label>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                <button className="btn btn-success btn-block" onClick={handleSubmit} disabled={answers.includes(null)}>
                    Submit
                </button>
                {score !== null && (
                    <h2 className="text-center mt-3">Your Score: {score.toFixed(2)}%</h2>
                )}
            </div>
        </div>
    );
};

export default App;
